from django.db import models

# Create your models here.
class basic(models.Model):
    date=models.DateField()
    website=models.CharField(max_length=100)
    heading=models.CharField(max_length=100)
    sub_heading=models.CharField(max_length=500)
    logo=models.ImageField(upload_to='images/')
class img(models.Model):
    image=models.ImageField(upload_to='images/')
class footer(models.Model):
    heading=models.CharField(max_length=100)
    call=models.IntegerField()
    email=models.EmailField()
    website=models.CharField(max_length=200)

