from django.shortcuts import render
from .models import footer
from .models import img
from .models import basic
def index(request):
    bas=basic.objects.all()
    image=img.objects.all()
    foo=footer.objects.all()
    context={
        'bas':bas,
        'image':image,
        'foo':foo
    }
    return render(request,'index.html',context)
# Create your views here.
