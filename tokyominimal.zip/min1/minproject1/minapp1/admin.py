from django.contrib import admin
from .models import basic
from .models import img
from.models import footer
admin.site.register(basic)
admin.site.register(img)
admin.site.register(footer)
# Register your models here.
