from django.urls import path
from . import views

urlpatterns = [
    path('',views.main),
    path('members/', views.members, name='members'),
    path('members/details/<int:id>', views.details, name='details'),   
    path('testing/',views.testing,name='testing'),
    path('test/',views.greet),
    path('member_list/',views.memb,name='member_list'),
    path('objecttest/',views.empty,name='test empty object'),
    path('querys/',views.set,name='query_set'),

]