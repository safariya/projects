from django.urls import path
from . import views

urlpatterns = [
    path('',views.main),
    path('members/', views.members, name='members'),
    path('members/details/<int:id>', views.details, name='details'),   
    path('testing/',views.testing,name='testing'),
    path('test/',views.greet),
    path('member_list/',views.memb,name='member_list'),
    path('objecttest/',views.empty,name='test empty object'),
    path('querys/',views.set,name='query_set'),
    path('members/delete/<int:id>/',views.delete,name="delete"),
    path('members/add_members/',views.add_members,name="add_members"),
    path('members/edit/<int:id>/',views.edit_members,name="edit"),

]