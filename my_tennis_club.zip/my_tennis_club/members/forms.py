from django import forms
from .models import Member
class Updateform(forms.ModelForm):
    class Meta:
        fields=('firstname','lastname','phone',)
        model=Member