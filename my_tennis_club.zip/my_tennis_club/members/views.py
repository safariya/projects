from django.http import HttpResponse
from django.template import loader
from .models import Member
from django.db.models import Q
from django.shortcuts import render,redirect
from django.contrib import messages
from .forms import Updateform
def members(request):
  mymembers = Member.objects.all().values()
  template = loader.get_template('all_members.html')
  context = {
    'mymembers': mymembers,
  }
  return HttpResponse(template.render(context, request))
  
def details(request, id):
  mymember = Member.objects.get(id=id)
  template = loader.get_template('details.html')
  context = {
    'mymember': mymember,
  }
  return HttpResponse(template.render(context, request))
def main(request):
  template=loader.get_template("main.html")
  return HttpResponse(template.render())
def testing(request):
  template=loader.get_template('template.html')
  context={
    'fruits':['apple','banana','cherry'],
  }
  return HttpResponse(template.render(context,request))
def greet(request):
  template=loader.get_template('templates.html')
  context={
    'cars':[
      {
        'name':'volvo',
        'price':'8616361',
        'year':'1964',
      },
      {
        'name':'kia',
        'price':'873827832',
        'year':'6536',
      },
    ]
  }
  return HttpResponse(template.render(context,request))
def memb(request):
  mymember=Member.objects.all().values()
  template=loader.get_template('member_list.html')
  context={
    'mymember':mymember,
  }
  return HttpResponse(template.render(context,request))
def empty(request):
  template=loader.get_template('template.html')
  context={
    'testobject':['apple','orange','kiwi'],
  }
  return HttpResponse(template.render(context,request))

def set(request):
  mymember=Member.objects.all()
  values=Member.objects.all().values()
  mylist=Member.objects.all().values_list('firstname')
  filterdata=Member.objects.filter(firstname='adam',lastname='muhammed').values()
  filteror=Member.objects.filter(firstname='safariya').values() | Member.objects.filter(lastname='muhammed').values()
  qfilter=Member.objects.filter(Q(firstname='safariya')|(Q(lastname='muhammed'))).values()
  startfilter=Member.objects.filter(firstname__startswith='l').values()
  orderby=Member.objects.all().order_by('firstname').values()
  dorderby=Member.objects.all().order_by("-firstname").values()
  bothad=Member.objects.all().order_by('firstname','-id').values()
  template=loader.get_template("query.html")
  context={
    'mymember':mymember,
    'values':values,
    'mylist':mylist,
    'filterdata':filterdata,
    'filteror':filteror,
    'qfilter':qfilter,
    'startfilter':startfilter,
    'orderby':orderby,
    'dorderby':dorderby,
    'bothad':bothad,
  }
  return HttpResponse(template.render(context,request))
def delete(request,id):
  mem=Member.objects.get(id=id)
  mem.delete()
  return redirect('members')
def add_members(request):
  if request.method=='POST':
    firstname=request.POST['firstname']
    lastname=request.POST['lastname']
    phone=request.POST['phone']
    joined_date=request.POST['joined_date']
    mem=Member(firstname=firstname,lastname=lastname,phone=phone,joined_date=joined_date)
    mem.save()
    messages.info(request,'added successfully')
    return redirect('members')
  else:
    return render(request,'add_members.html')
def edit_members(request,id):
  mem=Member.objects.get(id=id)
  form=Updateform(instance=mem)
  if request.method=='POST':
    form=Updateform(request.POST,instance=mem)
    if form.is_valid():
      form.save()
      return redirect('members')
    else:
      form=Updateform(instance=mem)
  else:
    context={'form':form,
             'mem':mem}
    return render(request,'edit_members.html',context)


